package me.jfenn.bingo.api.data

interface IBingoTeams: Iterable<IBingoTeam> {
    // fun create(id: String): IBingoTeam
}