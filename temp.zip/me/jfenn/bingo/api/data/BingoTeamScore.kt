package me.jfenn.bingo.api.data

class BingoTeamScore(
    val items: Int,
    val lines: Int,
    val cards: Int,
)
