package me.jfenn.bingo.api.config

interface IBingoConfig {
    val isLobbyMode: Boolean
}