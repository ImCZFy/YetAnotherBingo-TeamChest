package me.jfenn.bingo.api.event

import java.util.*

class TeamChangedEvent(
    val player: UUID,
)
