package me.jfenn.bingo.api.event

import java.util.*

class GameStartedEvent(
    val id: UUID
)
