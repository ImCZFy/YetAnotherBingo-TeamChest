package me.jfenn.bingo.api.event

import java.util.*

class GameEndedEvent(
    val id: UUID
)
